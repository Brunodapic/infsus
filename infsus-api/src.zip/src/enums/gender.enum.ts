export enum Gender {
  MALE = 'Male',
  FEMALE = 'Female',
}
