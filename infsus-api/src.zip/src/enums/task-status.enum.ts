export enum TaskStatusEnum {
  Dodijeljen = 'Dodijeljen',
  U_Tijeku = 'U_Tijeku',
  Ceka_Odobrenje = 'Ceka_Odobrenje',
  Pauziran = 'Pauziran',
  Zavrsen = 'Zavrsen',
  Provjerava_se = 'Provjerava_se',
  Zatvoren = 'Zatvoren',
}
