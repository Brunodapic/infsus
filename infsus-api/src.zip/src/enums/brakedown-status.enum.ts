export enum BreakdownStatusEnum {
  Prijavljen = 'Prijavljen',
  U_Analizi = 'U_Analizi',
  U_Obradi = 'U_Obradi',
  Ceka_se_dio = 'Ceka_se_dio',
  Zahtijeva_Dodatne_Informacije = 'Zahtijeva_Dodatne_Informacije',
  Riješen = 'Riješen',
  Zatvoren = 'Zatvoren',
  Odbijen = 'Odbijen',
}
