export enum UserRoleEnum {
  ADMIN = 'Admin',
  ORDERER = 'Orderer',
  EMPLOYEE = 'Employee',
}
