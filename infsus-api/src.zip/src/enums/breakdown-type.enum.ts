export enum BreakdownTypeEnum {
  Elektricni = 'Elektricni',
  Mehanicki = 'Mehanicki',
  Softverski = 'Softverski',
  Hidraulicni = 'Hidraulicni',
  Pneumatski = 'Pneumatski',
  Strukturalni = 'Strukturalni',
}
